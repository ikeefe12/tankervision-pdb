#pragma once

#include "BoardControl.h"

// Real-supercap charging and supervised source transfer. Own this object and
// BoardControl from one task. service() samples at 20 ms; transition operations
// use the driver's bounded setters. No serial, PD I2C, or flash access occurs here.
class SupercapTransfer {
 public:
  enum class State { Stopped, Charging, Ready, Backup, Returned, Fault, Cutoff };
  explicit SupercapTransfer(BoardControl &board) : board_(board) {}
  // The application must validate the actual input power budget first. Starting
  // is explicit and bounded; it does not happen automatically after boot/return.
  bool start(bool powerBudgetValidated);
  bool service();  // False for a latched fault; keep calling while active().
  bool stop();     // On backup, stops charging but retains voltage supervision.
  bool active() const { return monitoring_; }
  State state() const { return state_; }
  const char *stateName() const;
  const char *error() const { return error_; }
  const Status &lastStatus() const { return lastStatus_; }
  bool statusValid() const { return statusValid_; }
  float voltage() const { return lastStatus_.vcapV; }
  uint32_t samples() const { return samples_; }
  uint32_t lastSampleMs() const { return lastSampleAt_; }
  uint32_t maxServiceGapMs() const { return maxGapMs_; }
  uint32_t firstLossMs() const { return firstLossAt_; }
  uint32_t backupDurationMs() const;
  bool backupArmed() const { return backupArmed_; }
  bool backupConfirmed() const { return backupConfirmed_; }
  bool reachedReady() const { return reachedReady_; }
  // The application logs/commits its result, then deliberately calls
  // BoardControl::releaseBackupForShutdown(). No power-cut occurs in service().
  bool cutoffRequested() const { return state_ == State::Cutoff; }
  bool cleanupOk() const { return cleanupOk_ && !shutdownPending_; }

 private:
  BoardControl &board_;
  State state_ = State::Stopped;
  Status lastStatus_;
  char error_[192] = {};
  bool statusValid_ = false, monitoring_ = false, backupArmed_ = false;
  bool backupConfirmed_ = false, reachedReady_ = false, lossSeen_ = false;
  bool stopped_ = false, cleanupOk_ = true, shutdownPending_ = false;
  bool ceOffVerified_ = false, plateau_ = false, statLow_ = false;
  uint32_t startedAt_ = 0, lastSampleAt_ = 0, maxGapMs_ = 0, samples_ = 0;
  uint32_t firstLossAt_ = 0, backupConfirmedAt_ = 0, backupEndedAt_ = 0;
  uint32_t ceOffAt_ = 0, plateauAt_ = 0, statLowAt_ = 0;
  float plateauMin_ = 0, plateauMax_ = 0;
  bool fault(const char *reason);
  bool beginShutdown();
  bool finishShutdown(uint32_t now);
  bool clearExternalOutputs();
  bool setLedForVoltage();
  static bool mainValid(const Status &s);
};
